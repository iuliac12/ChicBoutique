window.addEventListener("load",function() {
    

    document.getElementById("inp-pret").onchange=function(){
        document.getElementById("infoRange").innerHTML=`(${this.value})` ///schimbam continutul
        ///functia e vazuta ca un obiect
    }


    ///document.getElementById("filtrare").addEventListener("click", function(){})
    ///pot sa adaug mai multe functii
    document.getElementById("filtrare").onclick = function()
    {
        var inpNume = document.getElementById("inp-nume").value.trim().toLowerCase();
        var vRadio = document.getElementsByName("gr_rad");
        var inpMarime;

        for(let r of vRadio){
            if(r.checked){
                ///atribut in html devine proprietate in javascript
                inpMarime = r.value;
                break;
            } 
        }
        let minMarime = 0, maxMarime = Infinity;
        if(inpMarime != "All") 
        {
            var aux = inpMarime.split(":");
            minMarime = parseInt(aux[0]);
            maxMarime = parseInt(aux[1]);
        }
        console.log('Marime minima: ', minMarime);
        console.log('Marime maxima: ', maxMarime);
        console.log('inp-marime: ', inpMarime);

        var inpPret= parseInt(document.getElementById("inp-pret").value);
        var inpCateg=document.getElementById("inp-categorie").value.toLowerCase().trim();

        ///alege culoare
        var inpColor = document.getElementById("color-choice").value.toLowerCase().trim();
        console.log('Culoare:', inpColor);

        var availableCheckbox = document.getElementById("available");
        var unavailableCheckbox = document.getElementById("unavailable");

        var inpStock = "";
        if (availableCheckbox.checked) inpStock = "available";
            else if (unavailableCheckbox.checked) inpStock = "unavailable";
        console.log('Stock: ', inpStock);

        /// Select multiplu
        var selectElement = document.getElementById("inp-categorie2");
        var selectedOptions = [];
        ///accesam proprietatea selectedOptions
        ///value returneaza doar prima optiune selectata
        for (var i = 0; i < selectElement.selectedOptions.length; i++) {
            selectedOptions.push(selectElement.selectedOptions[i].value.toLowerCase().trim());
        }
        console.log(selectedOptions); ///array de stringuri


        var produse=document.getElementsByClassName("produs");


        for(let produs of produse)
            {
                ///let valNume = document.getElementsByClassName("val-nume"); /// selecteaza numele tuturor produse
                let valNume = produs.getElementsByClassName("val-nume")[0].innerHTML.trim().toLowerCase(); ///selecteaza pentru fiecare produs in parte
                let cond1 = inpNume ? valNume.startsWith(inpNume) : true;

                let marimiText = produs.getElementsByClassName("val-marime")[1].innerHTML.trim();
                console.log(marimiText);
                let marimi = marimiText.split(',').map(m => parseInt(m.trim())); /// aplica functia de conversie pentru fiecare element
                console.log(marimi);
                console.log(marimi.some(m => m >= minMarime && m <= maxMarime ));

                let cond2 =(inpMarime == "all" || marimi.some(m => m >= minMarime && m <= maxMarime )); ///some() parcurge fiecare element si verifica conditia

                let valPret = parseInt(produs.getElementsByClassName("val-pret")[1].innerHTML);                
                let cond3 = (valPret >= inpPret);

                let valCategorie = produs.getElementsByClassName("val-categorie")[0].innerHTML.toLowerCase().trim();
                let cond4 = inpCateg ? (inpCateg == valCategorie || inpCateg == "all") : true;

                let valCuloare = produs.getElementsByClassName("val-culoare")[1].innerHTML.toLowerCase().trim();
                console.log('Culoare: ', valCuloare);
                let cond5 = inpCateg ? (valCuloare.startsWith(inpColor)) : true;

                let valStock = produs.getElementsByClassName("val-in_stoc")[1].innerHTML.toLowerCase().trim();
                console.log('Stock: ', valStock);
                conditie6 = (inpStock == 'available' && valStock == 'true') || (inpStock == 'unavailable' && valStock == 'false');
                let cond6 = inpStock ? conditie6 : true;

                ///select multiplu
                let materialeText = produs.getElementsByClassName("val-materiale")[1].innerHTML.trim();
                console.log('Materiale: ', materialeText);
                let materiale = materialeText.split(',').map(m => m.trim()); /// aplica functia de conversie pentru fiecare element
                console.log('Materiale array: ', materiale);
                let cond7 = selectedOptions == "all" || (materiale.some(m => selectedOptions.includes(m)));

                console.log('inp categorie', inpCateg);
                console.log('Cond1: ', cond1);
                console.log('Cond2: ',cond2);
                console.log('Cond3: ',cond3);
                console.log('Cond4: ',cond4);
                console.log('Cond6: ',cond6);


                if(cond1 && cond2 && cond3 && cond4 && cond5 && cond6 && cond7){
                    produs.style.display = "block";
                }
                else{
                    produs.style.display = "none";
                }
            }
    }
    document.getElementById("resetare").onclick= function(){
                
        document.getElementById("inp-nume").value="";
        
        document.getElementById("inp-pret").value=document.getElementById("inp-pret").min;
        document.getElementById("inp-categorie").value="toate";
        document.getElementById("i_rad4").checked=true;
        var produse=document.getElementsByClassName("produs");
        document.getElementById("infoRange").innerHTML="(0)";
        for (let prod of produse){
            prod.style.display="block";
        }
    }

    function sorteaza (semn)
    {
        var produse=document.getElementsByClassName("produs");
        let v_produse=Array.from(produse); ///primeste orice obiect si genereaza un vector cu acelasi continut = "conversie"
        /// sort by defualt sorteaza lexicografic
        console.log(v_produse[0]);
        v_produse.sort(function(a,b)
        {
            /// a si b sun produse => article
            let pret_a=parseInt(a.getElementsByClassName("val-pret")[1].innerHTML)
            let pret_b=parseInt(b.getElementsByClassName("val-pret")[1].innerHTML)
            // console.log('Pret a: ', pret_a);
            // console.log('Pret b: ', pret_b);
            if (pret_a == pret_b)
            {
                let nume_a = a.getElementsByClassName("val-nume")[0].innerHTML
                let nume_b = b.getElementsByClassName("val-nume")[0].innerHTML
                return semn*nume_a.localeCompare(nume_b); ///compara 2 stringuri

                // console.log('Nume a: ', nume_a);
                // console.log('Nume b: ', nume_b);
            }
            return semn*(pret_a-pret_b);
        })
        console.log(v_produse);
        for (let prod of v_produse){
            prod.parentNode.appendChild(prod);  ///adauga la final in ordinea sortata
        }

    }
    
        document.getElementById("sortCrescNume").onclick= function(){
            console.log("Sorteaza crescator!");            
            sorteaza(1);
        }
        document.getElementById("sortDescrescNume").onclick= function(){
            
            console.log("Sorteaza descrescator!");
            sorteaza(-1);
        }


        /* Tasta apasata */ 
        window.onkeydown=function(e)
        {
            if (e.key=="c" && e.altKey) ///altkey e bool
            {
                var suma = 0;
                var produse=document.getElementsByClassName("produs");
                for (let produs of produse)
                {
                    ///verificam stilizarea css
                    var stil=getComputedStyle(produs) ///stilul calculat de peste tot
                    if (stil.display != "none")
                    {
                        suma += parseFloat(produs.getElementsByClassName("val-pret")[1].innerHTML)
                    }
                }

                console.log('Suma = ', suma);
                if (!document.getElementById("par_suma")){
                    let p= document.createElement("p")
                    p.innerHTML=suma;
                    p.id="par_suma";
                    container=document.getElementById("produse")
                    ///appendchild adauga la final
                    container.insertBefore(p,container.children[0])
                    setTimeout(function(){
                        var pgf=document.getElementById("par_suma")
                        if(pgf)
                            pgf.remove()
                    }, 2000)
                }
    
            }
        }
   
})